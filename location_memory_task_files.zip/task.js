/* =========================================================================
   VISUAL LOCATION MEMORY TASK
   Vanilla JS experiment engine (no libraries, runs locally from file://)
   Participants: children and adolescents, approx. 8-16 years.

   Structure of this file
     1.  CONFIGURATION            (all tunable settings)
     2.  ICON LIBRARY             (inline SVG, no OS emoji)
     3.  STIMULUS POOLS
     4.  UTILITIES
     5.  TRIAL GENERATION + RANDOMISATION
     6.  DOM SETUP + GRID BUILDER
     7.  EVENT LOG + AOI CAPTURE
     8.  TRIAL ENGINE (slide sequence, two attempts per trial)
     9.  BLOCK / SESSION FLOW
    10.  SUMMARY STATISTICS
    11.  DATA EXPORT (CSV + JSON)

   Internal condition codes (never shown to participants):
     Part 1 = condition_A   (4 boxes,  3 fruit objects)
     Part 2 = condition_B   (6 boxes,  4 unrelated objects)
     Part 3 = condition_C   (9 boxes,  6 unrelated objects)
   ========================================================================= */


/* =========================================================================
   1. CONFIGURATION
   ========================================================================= */

const PART1_TRIALS          = 10;
const PART2_TRIALS          = 10;
const PART3_TRIALS          = 10;

/* Grid for each part, given as rows x columns.
   Part 1 -> 2 x 2 = 4 boxes
   Part 2 -> 2 x 3 = 6 boxes
   Part 3 -> 3 x 3 = 9 boxes
   Cell size, icon size and AOI labels all recalculate themselves. */
const PART1_GRID            = { rows: 2, cols: 2 };
const PART2_GRID            = { rows: 2, cols: 3 };
const PART3_GRID            = { rows: 3, cols: 3 };

/* How many objects have to be remembered in each part. */
const PART1_OBJECT_COUNT    = 3;
const PART2_OBJECT_COUNT    = 4;
const PART3_OBJECT_COUNT    = 6;

/* Which stimulus pool each part draws from:
   'fruits'  = one familiar category
   'objects' = deliberately unrelated everyday objects */
const PART1_POOL            = 'fruits';
const PART2_POOL            = 'objects';
const PART3_POOL            = 'objects';

const FIXATION_DURATION_MS  = 500;   // the + is shown alone, with no boxes
const MEMORY_DURATION_MS    = 2500;
const RETENTION_DURATION_MS = 1200;
const RESPONSE_TIMEOUT_MS   = 0;      // 0 = wait indefinitely for an answer
const PRACTICE_TRIALS       = 3;

const MAX_ATTEMPTS          = 2;      // one extra chance after a wrong answer
const FEEDBACK_DURATION_MS  = 900;    // how long "Correct!" stays on screen
const PRACTICE_FEEDBACK_MS  = 1100;   // practice feedback, long enough for the clap
const SHAKE_DURATION_MS     = 520;    // must match the CSS shake animation
const HINT_DURATION_MS      = 1000;   // how long the peek under a wrong box lasts
const SHOW_HINT             = true;   // reveal what was under the first wrong box

const ITI_MIN_MS            = 800;
const ITI_MAX_MS            = 1200;

/* Semantic-similarity control for the unrelated-object parts:
   at most 2 objects from one category, and at least (n - 1) categories
   represented in a set of n objects. */
const MAX_PER_CATEGORY        = 2;

/* Request fullscreen when the session starts (recommended for eye tracking) */
const REQUEST_FULLSCREEN    = true;

/* In this multi-file build every trial is already its own physical .html
   file reached by a REAL page load (location.href), which is what Tobii Pro
   Lab registers as a distinct page visit. So the in-page history.pushState is
   turned OFF here: with the flag false, setPageUrl() just returns
   location.href, so each file maps to exactly ONE real URL with no post-load
   rewrite. (pushState only changed the address bar without a real navigation,
   which Tobii does not register as a new page — the original bug.) */
const UNIQUE_URL_PER_TRIAL  = false;
const URL_HISTORY_MODE      = 'push';

/* Grid geometry, in design pixels on the 1920 x 1080 surface.
   The grid always fills the same square and stays centred on the same
   point, so fewer boxes automatically means larger boxes and icons. */
const GRID_AREA_PX          = 866;    // vertical budget for the grid
const GRID_MAX_WIDTH_PX     = 1500;   // horizontal budget for the grid
const CELL_GAP_PX           = 18;
const ICON_FILL_RATIO       = 0.95;   // icon size as a proportion of the cell

/* Words used to build human-readable AOI labels */
const ROW_WORDS = { 2: ['upper', 'lower'], 3: ['upper', 'middle', 'lower'] };
const COL_WORDS = { 2: ['left', 'right'],  3: ['left', 'center', 'right']  };


/* ---------- Language ----------
   'en' or 'ar'. This is the ONLY difference between the English and the
   Arabic build; the task itself is identical in both. */
const LANG = 'en';

const STRINGS = {
  en: {
    docTitle:    'Location Memory Game',
    welcomeTitle:'Location Memory Game',
    welcome1:    'You will see some pictures appear on the screen.',
    welcome2:    'Try to remember where each picture is.',
    welcome3:    'The pictures will disappear.',
    welcome4:    'Then you will see one picture again.',
    welcome5:    'Click the place where you remember seeing it.',
    pidLabel:    'Participant ID',
    pidPlaceholder: 'e.g. P001',
    pidError:    'Enter a Participant ID to continue.',
    start:       'Start',
    begin:       'Begin',
    continueBtn: 'Continue',
    practiceTitle: 'Practice',
    instruction: 'Remember where the pictures are.',
    part1Title:  'Part 1',
    part2Title:  'Part 2',
    part3Title:  'Part 3',
    break1Title: 'Great! Part 1 is complete.',
    break2Title: 'Great! Part 2 is complete.',
    breakBody:   'You can take a short break.',
    endTitle:    'All done!',
    endBody:     'Thank you for completing the activity.',
    prompt:      'Where was this picture?',
    correct:     'Correct!',
    tryNext:     'Try the next one!',
    emptyBox:    'Nothing here',
    progress:         (i, n) => `${i} of ${n}`,
    practiceProgress: (i, n) => `Practice ${i} of ${n}`,
    footerNote:  'Researcher use',
    downloadCsv: 'Download Data',
    downloadJson:'Download Event Log'
  },
  ar: {
    docTitle:    'لعبة تذكّر الأماكن',
    welcomeTitle:'لعبة تذكّر الأماكن',
    welcome1:    'سترى صورًا تظهر على الشاشة.',
    welcome2:    'حاول أن تتذكّر مكان كل صورة.',
    welcome3:    'ثم تختفي الصور.',
    welcome4:    'بعدها ترى صورة واحدة مرة أخرى.',
    welcome5:    'اضغط على المكان الذي رأيت فيه تلك الصورة.',
    pidLabel:    'رقم المشارك',
    pidPlaceholder: 'مثال: P001',
    pidError:    'أدخل رقم المشارك للمتابعة.',
    start:       'ابدأ',
    begin:       'ابدأ',
    continueBtn: 'متابعة',
    practiceTitle: 'تدريب',
    instruction: 'تذكّر أماكن الصور.',
    part1Title:  'الجزء الأول',
    part2Title:  'الجزء الثاني',
    part3Title:  'الجزء الثالث',
    break1Title: 'أحسنت! انتهى الجزء الأول.',
    break2Title: 'أحسنت! انتهى الجزء الثاني.',
    breakBody:   'يمكنك أخذ استراحة قصيرة.',
    endTitle:    'انتهينا!',
    endBody:     'شكرًا لإكمالك النشاط.',
    prompt:      'أين كانت هذه الصورة؟',
    correct:     'أحسنت!',
    tryNext:     'جرّب الصورة التالية!',
    emptyBox:    'فارغ',
    progress:         (i, n) => `${i} من ${n}`,
    practiceProgress: (i, n) => `تدريب ${i} من ${n}`,
    footerNote:  'لاستخدام الباحث',
    downloadCsv: 'تنزيل البيانات',
    downloadJson:'تنزيل سجل الأحداث'
  }
};

const S = STRINGS[LANG];

/* =========================================================================
   2. ICON LIBRARY
   Inline SVG so that appearance is identical on every computer.
   All icons share a 100x100 viewBox, the same dark outline weight and
   comparable visual mass / brightness. No text labels.
   ========================================================================= */

const ICON_STROKE = 'fill="none" stroke="#3A3F47" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"';

/** Wrap icon shapes in a consistent SVG frame. */
function svgIcon(shapes){
  return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true">
            <g ${ICON_STROKE}>${shapes}</g>
          </svg>`;
}

const ICON_SHAPES = {

  /* ---------- fruits (Part 1) ---------- */
  apple: `<path d="M50 35c-6-8-18-10-25-3-9 8-7 25 0 36 4 8 10 16 17 16 3 0 5-1 8-1s5 1 8 1c7 0 13-8 17-16 7-11 9-28 0-36-7-7-19-5-25 3z" fill="#E4635C"/>
          <path d="M50 35V20"/>
          <path d="M52 27c5-9 15-12 21-10 0 8-7 15-16 15-3 0-5-2-5-5z" fill="#62AF69"/>
          <ellipse cx="36" cy="50" rx="5" ry="9" transform="rotate(-28 36 50)" fill="#fff" opacity=".4" stroke="none"/>`,

  banana: `<path d="M23 25c0 31 21 54 48 54 8 0 13-4 13-9 0-4-4-6-9-5-21 4-40-16-43-41-1-6-9-5-9 1z" fill="#F0C64B"/>
           <path d="M35 32c4 20 18 34 36 37" stroke="#fff" stroke-width="4" opacity=".4"/>
           <path d="M23 25c-1-5 2-8 6-8" stroke-width="4"/>
           <path d="M84 70c2 2 3 4 2 6" stroke-width="4"/>`,

  orange: `<circle cx="50" cy="58" r="29" fill="#F0973F"/>
           <g stroke="#fff" stroke-width="2.2" opacity=".45"><path d="M50 31v54M28 46l44 24M28 70l44-24"/></g>
           <path d="M50 30V22"/>
           <path d="M52 25c5-8 14-10 19-9 0 7-6 13-14 13-3 0-5-1-5-4z" fill="#62AF69"/>
           <ellipse cx="37" cy="47" rx="6" ry="9" transform="rotate(-30 37 47)" fill="#fff" opacity=".35" stroke="none"/>`,

  strawberry: `<path d="M50 89C33 79 25 65 25 53c0-11 11-18 25-18s25 7 25 18c0 12-8 26-25 36z" fill="#E4635C"/>
               <path d="M50 36c-9-6-19-6-25 0 5 7 14 9 25 7zM50 36c9-6 19-6 25 0-5 7-14 9-25 7z" fill="#62AF69"/>
               <path d="M50 36V24"/>
               <g fill="#F0C64B" stroke="none"><ellipse cx="41" cy="52" rx="2.6" ry="3.4"/><ellipse cx="59" cy="52" rx="2.6" ry="3.4"/><ellipse cx="50" cy="62" rx="2.6" ry="3.4"/><ellipse cx="35" cy="63" rx="2.6" ry="3.4"/><ellipse cx="65" cy="63" rx="2.6" ry="3.4"/><ellipse cx="50" cy="75" rx="2.6" ry="3.4"/></g>`,

  grapes: `<path d="M50 40V25"/>
           <path d="M52 27c5-8 14-10 19-9 0 7-6 13-14 13-3 0-5-1-5-4z" fill="#62AF69"/>
           <circle cx="50" cy="46" r="11.5" fill="#9B78C0"/>
           <circle cx="36" cy="56" r="11.5" fill="#9B78C0"/>
           <circle cx="64" cy="56" r="11.5" fill="#9B78C0"/>
           <circle cx="43" cy="69" r="11.5" fill="#9B78C0"/>
           <circle cx="57" cy="69" r="11.5" fill="#9B78C0"/>
           <circle cx="50" cy="81" r="11.5" fill="#9B78C0"/>
           <g fill="#fff" opacity=".33" stroke="none"><circle cx="46" cy="42" r="3.4"/><circle cx="32" cy="52" r="3.4"/></g>`,

  watermelon: `<path d="M11 33a39 39 0 0 0 78 0z" fill="#62AF69"/>
               <path d="M17 39a33 33 0 0 0 66 0z" fill="#F0DCC0"/>
               <path d="M21 43a29 29 0 0 0 58 0z" fill="#E4635C"/>
               <g fill="#3A3F47" stroke="none"><ellipse cx="38" cy="54" rx="2.4" ry="3.2"/><ellipse cx="62" cy="54" rx="2.4" ry="3.2"/><ellipse cx="50" cy="63" rx="2.4" ry="3.2"/></g>`,

  pear: `<path d="M50 26c-8 0-12 8-9 15 3 8-16 12-16 30 0 14 11 22 25 22s25-8 25-22c0-18-19-22-16-30 3-7-1-15-9-15z" fill="#B7C64F"/>
         <path d="M50 26V16"/>
         <path d="M52 20c5-7 13-8 17-7 0 6-6 12-13 12-3 0-4-2-4-5z" fill="#62AF69"/>
         <ellipse cx="37" cy="62" rx="5" ry="9" transform="rotate(-18 37 62)" fill="#fff" opacity=".35" stroke="none"/>`,

  pineapple: `<path d="M50 37c-4-12-12-19-21-21 4 12 6 18 11 22M50 37c4-12 12-19 21-21-4 12-6 18-11 22M50 37c-3-13-2-21 0-25 3 7 5 15 5 25z" fill="#62AF69"/>
              <ellipse cx="50" cy="64" rx="24" ry="26" fill="#F0C64B"/>
              <g stroke="#B98253" stroke-width="2.2" opacity=".7"><path d="M31 51l38 26M69 51L31 77M50 38v52"/></g>`,

  cherry: `<path d="M34 68C36 50 44 34 54 25M66 68C62 51 59 35 54 25"/>
           <path d="M56 25c6-8 16-9 21-7-1 7-8 12-15 12-3 0-5-2-6-5z" fill="#62AF69"/>
           <circle cx="32" cy="76" r="13" fill="#E4635C"/>
           <circle cx="68" cy="76" r="13" fill="#E4635C"/>
           <g fill="#fff" opacity=".35" stroke="none"><circle cx="28" cy="72" r="3.6"/><circle cx="64" cy="72" r="3.6"/></g>`,

  peach: `<circle cx="50" cy="60" r="29" fill="#EE8A6B"/>
          <path d="M50 33c-4 18-4 36 0 55" stroke="#fff" stroke-width="2.6" opacity=".45"/>
          <path d="M50 32V24"/>
          <path d="M52 27c5-8 14-10 19-9 0 7-6 13-14 13-3 0-5-1-5-4z" fill="#62AF69"/>
          <ellipse cx="36" cy="49" rx="6" ry="9" transform="rotate(-30 36 49)" fill="#fff" opacity=".35" stroke="none"/>`,

  /* ---------- everyday objects (Parts 2 and 3) ---------- */
  key: `<circle cx="50" cy="29" r="16" fill="#F0C64B"/>
        <circle cx="50" cy="29" r="6" fill="#fff"/>
        <path d="M44 44h12v42H44z" fill="#F0C64B"/>
        <path d="M56 57h13v9H56zM56 72h11v9H56z" fill="#F0C64B"/>
        <path d="M46 48v34" stroke="#fff" stroke-width="2.4" opacity=".5"/>`,

  car: `<path d="M13 69V56c0-4 3-6 6-6h6l10-14c1-2 3-3 5-3h22c2 0 4 1 5 3l9 14h5c4 0 6 2 6 6v13z" fill="#5B94C4"/>
        <path d="M38 50l6-10h9v10zM57 50V40h4l7 10z" fill="#EAF2F7"/>
        <path d="M13 62h74" stroke="#fff" stroke-width="2.4" opacity=".4"/>
        <circle cx="30" cy="70" r="10" fill="#5C6E7E"/>
        <circle cx="70" cy="70" r="10" fill="#5C6E7E"/>
        <circle cx="30" cy="70" r="4" fill="#EAF2F7"/>
        <circle cx="70" cy="70" r="4" fill="#EAF2F7"/>`,

  bee: `<ellipse cx="40" cy="34" rx="15" ry="9" transform="rotate(-22 40 34)" fill="#EAF2F7"/>
        <ellipse cx="60" cy="34" rx="15" ry="9" transform="rotate(22 60 34)" fill="#EAF2F7"/>
        <ellipse cx="50" cy="62" rx="25" ry="19" fill="#F0C64B"/>
        <path d="M41 46v32M57 45v34" stroke="#3A3F47" stroke-width="8"/>
        <path d="M33 46c-4-6-8-10-12-12M67 46c4-6 8-10 12-12"/>
        <circle cx="19" cy="32" r="3.4" fill="#3A3F47"/>
        <circle cx="81" cy="32" r="3.4" fill="#3A3F47"/>`,

  shoe: `<path d="M13 73V57c0-4 3-7 7-7h8c2 0 3 0 5 2l10 7c6 4 13 6 22 7 8 1 13 4 14 9l1 5H17c-2 0-4-2-4-5z" fill="#5B94C4"/>
         <path d="M11 73h78c0 6-4 10-10 10H20c-6 0-9-4-9-10z" fill="#EAF2F7"/>
         <path d="M34 57l7 6M45 62l7 6M56 66l7 4" stroke="#EAF2F7" stroke-width="3"/>`,

  clock: `<circle cx="50" cy="56" r="31" fill="#4FA8B8"/>
          <circle cx="50" cy="56" r="24" fill="#fff"/>
          <path d="M50 38v18l13 8"/>
          <circle cx="50" cy="56" r="3.4" fill="#3A3F47"/>
          <g stroke-width="3"><path d="M50 30v.1M50 82v.1M24 56h.1M76 56h.1"/></g>`,

  book: `<path d="M50 33c-8-6-19-8-31-7v46c12-1 23 1 31 7z" fill="#E4635C"/>
         <path d="M50 33c8-6 19-8 31-7v46c-12-1-23 1-31 7z" fill="#5B94C4"/>
         <path d="M50 33v46"/>
         <g stroke="#fff" stroke-width="2.4" opacity=".5"><path d="M27 40h15M27 50h15M58 40h15M58 50h15"/></g>`,

  umbrella: `<path d="M14 54a36 36 0 0 1 72 0z" fill="#E4635C"/>
             <path d="M14 54c6-7 12-7 18 0 6-7 12-7 18 0 6-7 12-7 18 0 6-7 12-7 18 0" fill="#EE8A6B"/>
             <path d="M50 54v26a9 9 0 0 1-18 0"/>
             <path d="M50 18v-4"/>`,

  bicycle: `<circle cx="25" cy="67" r="17" fill="#EAF2F7"/>
            <circle cx="75" cy="67" r="17" fill="#EAF2F7"/>
            <g stroke="#4FA8B8" stroke-width="6"><path d="M25 67l15-25h22l13 25M40 42h19M50 67l13-25"/></g>
            <path d="M36 40h10" stroke-width="4"/>
            <circle cx="25" cy="67" r="3.6" fill="#3A3F47"/>
            <circle cx="75" cy="67" r="3.6" fill="#3A3F47"/>`,

  cup: `<path d="M25 35h42v29c0 9-7 16-16 16h-10c-9 0-16-7-16-16z" fill="#5B94C4"/>
        <path d="M67 44h6a10 10 0 0 1 0 21h-6"/>
        <path d="M25 45h42" stroke="#fff" stroke-width="3" opacity=".55"/>
        <path d="M38 22c4 5-4 8 0 13M52 22c4 5-4 8 0 13" stroke-width="3"/>`,

  star: `<path d="M50 18l10 21 23 3-17 16 4 23-20-11-20 11 4-23-17-16 23-3z" fill="#F0C64B"/>
         <path d="M50 30l5 12 13 2-9 9 2 13-11-6-11 6 2-13-9-9 13-2z" fill="#fff" opacity=".3" stroke="none"/>`,

  camera: `<path d="M37 38l5-9h16l5 9" fill="#5C6E7E"/>
           <rect x="14" y="38" width="72" height="43" rx="9" fill="#5C6E7E"/>
           <circle cx="50" cy="60" r="16" fill="#EAF2F7"/>
           <circle cx="50" cy="60" r="8" fill="#4FA8B8"/>
           <circle cx="75" cy="47" r="3.6" fill="#F0C64B"/>`,

  ball: `<circle cx="50" cy="57" r="30" fill="#fff"/>
         <path d="M50 41l14 10-5 17H41l-5-17z" fill="#5C6E7E"/>
         <path d="M50 27v14M64 51l14-5M59 68l9 13M41 68l-9 13M36 51l-14-5"/>`,

  chair: `<path d="M30 20h40a6 6 0 0 1 6 6v28H24V26a6 6 0 0 1 6-6z" fill="#B98253"/>
          <g stroke="#F0DCC0" stroke-width="3"><path d="M40 28v20M50 28v20M60 28v20"/></g>
          <rect x="19" y="53" width="62" height="13" rx="6" fill="#C99A6B"/>
          <path d="M28 66v20M72 66v20" stroke-width="9" stroke="#B98253"/>
          <path d="M28 66v20M72 66v20"/>`,

  fish: `<path d="M12 57c11-16 31-22 46-18 11 3 16 12 16 18s-5 15-16 18c-15 4-35-2-46-18z" fill="#4FA8B8"/>
         <path d="M74 57l16-14v28z" fill="#4FA8B8"/>
         <path d="M44 42c5 9 5 21 0 29" stroke="#fff" stroke-width="3" opacity=".5"/>
         <circle cx="28" cy="52" r="4" fill="#fff"/>
         <circle cx="28" cy="52" r="2" fill="#3A3F47"/>`,

  flower: `<path d="M50 60v27M50 78c-9 0-14-5-15-12 9-1 14 4 15 12z" fill="#62AF69"/>
           <g fill="#E387A6">
             <ellipse cx="50" cy="32" rx="11" ry="15"/>
             <ellipse cx="50" cy="32" rx="11" ry="15" transform="rotate(72 50 51)"/>
             <ellipse cx="50" cy="32" rx="11" ry="15" transform="rotate(144 50 51)"/>
             <ellipse cx="50" cy="32" rx="11" ry="15" transform="rotate(216 50 51)"/>
             <ellipse cx="50" cy="32" rx="11" ry="15" transform="rotate(288 50 51)"/>
           </g>
           <circle cx="50" cy="51" r="11" fill="#F0C64B"/>`,

  airplane: `<path d="M50 13c6 0 9 9 9 20v10l29 18v10l-29-8v14l10 9v7l-19-6-19 6v-7l10-9V63l-29 8V61l29-18V33c0-11 3-20 9-20z" fill="#5B94C4"/>
             <path d="M50 22c2 5 2 12 2 21" stroke="#fff" stroke-width="3" opacity=".45"/>`,

  pencil: `<path d="M39 19h22a4 4 0 0 1 4 4v8H35v-8a4 4 0 0 1 4-4z" fill="#E387A6"/>
           <rect x="35" y="31" width="30" height="8" fill="#EAF2F7"/>
           <rect x="35" y="39" width="30" height="32" fill="#F0C64B"/>
           <path d="M35 71h30L50 89z" fill="#F0DCC0"/>
           <path d="M43 82h14l-7 7z" fill="#3A3F47"/>
           <path d="M50 39v32" stroke="#B98253" stroke-width="2.4" opacity=".6"/>`,

  house: `<path d="M12 51L50 20l38 31z" fill="#E4635C"/>
          <path d="M22 51h56v34H22z" fill="#F0DCC0"/>
          <path d="M42 85V64h16v21z" fill="#B98253"/>
          <rect x="28" y="58" width="10" height="10" rx="2" fill="#5B94C4"/>
          <rect x="62" y="58" width="10" height="10" rx="2" fill="#5B94C4"/>`,

  moon: `<path d="M63 15a37 37 0 1 0 0 72 42 42 0 0 1 0-72z" fill="#F0C64B"/>
         <g fill="#fff" opacity=".4" stroke="none"><circle cx="45" cy="36" r="4"/><circle cx="38" cy="55" r="5.5"/><circle cx="49" cy="66" r="3.4"/></g>`
};

/* Clapping hands, shown after each practice trial only. */
const CLAP_SHAPES = `
  <g transform="rotate(-17 42 62)">
    <path d="M26 58c-8-1-13 4-11 10 2 6 9 8 14 6z" fill="#EE8A6B"/>
    <rect x="24" y="38" width="30" height="46" rx="14" fill="#EE8A6B"/>
    <g stroke="#fff" stroke-width="2.4" opacity=".5"><path d="M32 48v26M40 46v30M48 50v22"/></g>
  </g>
  <g transform="rotate(17 60 62)">
    <path d="M76 58c8-1 13 4 11 10-2 6-9 8-14 6z" fill="#F0B48A"/>
    <rect x="48" y="38" width="30" height="46" rx="14" fill="#F0B48A"/>
    <g stroke="#fff" stroke-width="2.4" opacity=".5"><path d="M56 50v22M64 46v30M72 48v26"/></g>
  </g>
  <g stroke-width="4.5"><path d="M50 26v-10M31 30l-6-8M69 30l6-8M18 48l-9-4M82 48l9-4"/></g>`;

const CLAP_HTML = svgIcon(CLAP_SHAPES);

/** Cache of rendered icon markup. */
const ICON_HTML = {};
for (const name of Object.keys(ICON_SHAPES)) ICON_HTML[name] = svgIcon(ICON_SHAPES[name]);


/* =========================================================================
   3. STIMULUS POOLS
   ========================================================================= */

// Part 1 (condition_A): fruits only — one familiar semantic category.
const FRUIT_POOL = [
  'apple','banana','orange','strawberry','grapes',
  'watermelon','pear','pineapple','cherry','peach'
];

// Part 2 (condition_B): unrelated everyday objects.
// Category tags are used ONLY to prevent semantically coherent sets.
const OBJECT_POOL = [
  { name: 'key',      category: 'tools'      },
  { name: 'car',      category: 'vehicles'   },
  { name: 'apple',    category: 'food'       },
  { name: 'bee',      category: 'nature'     },
  { name: 'shoe',     category: 'clothing'   },
  { name: 'clock',    category: 'devices'    },
  { name: 'book',     category: 'stationery' },
  { name: 'umbrella', category: 'accessories'},
  { name: 'bicycle',  category: 'vehicles'   },
  { name: 'cup',      category: 'kitchen'    },
  { name: 'star',     category: 'sky'        },
  { name: 'camera',   category: 'devices'    },
  { name: 'ball',     category: 'play'       },
  { name: 'chair',    category: 'furniture'  },
  { name: 'fish',     category: 'nature'     },
  { name: 'flower',   category: 'nature'     },
  { name: 'airplane', category: 'vehicles'   },
  { name: 'pencil',   category: 'stationery' },
  { name: 'house',    category: 'buildings'  },
  { name: 'moon',     category: 'sky'        }
];


/* =========================================================================
   4. UTILITIES
   ========================================================================= */

const sleep = ms => new Promise(res => setTimeout(res, ms));

function randInt(min, max){                       // inclusive
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function shuffle(arr){
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--){
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function sampleN(arr, n){ return shuffle(arr).slice(0, n); }

function pad2(n){ return String(n).padStart(2, '0'); }

function isoNow(){ return new Date().toISOString(); }

function dateStamp(){
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function round2(x){
  return (x === null || x === undefined || Number.isNaN(x)) ? '' : Math.round(x * 100) / 100;
}

/* ---------- AOI helpers ----------
   AOIs are numbered in reading order: AOI_1 is the top-left box and the
   last AOI is the bottom-right box, for whatever grid size is in use. */

function gridKey(grid){ return `${grid.rows}x${grid.cols}`; }

function gridCells(grid){ return grid.rows * grid.cols; }

function aoiIdsFor(grid){
  const out = [];
  for (let i = 1; i <= gridCells(grid); i++) out.push('AOI_' + i);
  return out;
}

function aoiLabelFor(grid, index){       // index is 0-based, reading order
  const r = Math.floor(index / grid.cols), c = index % grid.cols;
  const rowWord = (ROW_WORDS[grid.rows] || [])[r] || `row ${r + 1}`;
  const colWord = (COL_WORDS[grid.cols] || [])[c] || `column ${c + 1}`;
  if (rowWord === 'middle' && colWord === 'center') return 'center';
  return `${rowWord} ${colWord}`;
}

function aoiLabelMapFor(grid){
  const map = {};
  aoiIdsFor(grid).forEach((id, i) => { map[id] = aoiLabelFor(grid, i); });
  return map;
}


/* =========================================================================
   5. TRIAL GENERATION + RANDOMISATION
   Randomisation happens once, before the session starts, and the whole
   configuration is saved into the exported data.
   ========================================================================= */

/**
 * Target-location sequence balanced as evenly as possible across the
 * available AOIs, with no immediate repetition of the same AOI.
 */
function balancedTargetLocations(nTrials, ids){
  const pool = [];
  while (pool.length < nTrials) pool.push(...shuffle(ids));
  const counts = pool.slice(0, nTrials);

  const hasRepeat = seq => seq.some((v, i) => i > 0 && v === seq[i - 1]);
  let seq = shuffle(counts);
  let attempts = 0;
  while (hasRepeat(seq) && attempts++ < 500) seq = shuffle(counts);
  return seq;
}

/** True if a set of objects is sufficiently semantically unrelated. */
function isUnrelatedSet(objs){
  const counts = {};
  objs.forEach(o => { counts[o.category] = (counts[o.category] || 0) + 1; });
  const distinct = Object.keys(counts).length;
  const maxInOne = Math.max(...Object.values(counts));
  return distinct >= objs.length - 1 && maxInOne <= MAX_PER_CATEGORY;
}

/** Draw n unrelated objects (retry until the semantic constraint is met). */
function drawUnrelatedObjects(n){
  for (let i = 0; i < 400; i++){
    const set = sampleN(OBJECT_POOL, n);
    if (isUnrelatedSet(set)) return set.map(o => o.name);
  }
  const byCat = {};
  shuffle(OBJECT_POOL).forEach(o => { (byCat[o.category] = byCat[o.category] || []).push(o); });
  const picked = [];
  Object.values(byCat).forEach(list => { if (picked.length < n) picked.push(list[0]); });
  return picked.slice(0, n).map(o => o.name);
}

/**
 * Build one block of trials.
 * @param {string} part          'Part 1' | 'Part 2' | 'Practice'
 * @param {string} conditionCode 'condition_A' | 'condition_B' | 'practice'
 * @param {number} nTrials
 * @param {number} nObjects
 * @param {object} grid          { rows, cols }
 * @param {string} pool          'fruits' | 'objects'
 */
function buildBlock(part, conditionCode, nTrials, nObjects, grid, pool){
  const ids = aoiIdsFor(grid);
  const targetLocations = balancedTargetLocations(nTrials, ids);
  const trials = [];
  let previousLocationKey = '';

  for (let t = 0; t < nTrials; t++){
    let objects, locations, locationKey;
    let guard = 0;

    do {
      objects = (pool === 'fruits')
        ? sampleN(FRUIT_POOL, nObjects)                // different fruits
        : drawUnrelatedObjects(nObjects);              // unrelated objects

      const targetAOI = targetLocations[t];
      const others = sampleN(ids.filter(a => a !== targetAOI), nObjects - 1);
      locations = [targetAOI, ...others];              // index 0 == target object

      locationKey = locations.slice().sort().join('|');
      guard++;
    } while (locationKey === previousLocationKey && guard < 50);

    previousLocationKey = locationKey;

    const placement = {};
    objects.forEach((obj, i) => { placement[locations[i]] = obj; });

    trials.push({
      part,
      condition_code: conditionCode,
      trial_number: t + 1,
      grid_size: gridKey(grid),
      n_grid_locations: gridCells(grid),
      grid,
      number_of_objects: nObjects,
      objects_presented: objects.slice(),
      placement,                                       // { AOI_x: objectName }
      target_object: objects[0],
      target_correct_location: locations[0],
      attempts: []
    });
  }
  return trials;
}


/* =========================================================================
   6. DOM SETUP + GRID BUILDER
   ========================================================================= */

const el = {
  stage:          document.getElementById('stage'),
  taskLayer:      document.getElementById('task-layer'),
  promptText:     document.getElementById('prompt-text'),
  targetIcon:     document.getElementById('target-icon'),
  feedbackText:   document.getElementById('feedback-text'),
  fixation:       document.getElementById('fixation'),
  grid:           document.getElementById('grid'),
  progress:       document.getElementById('progress'),
  screens: {
    welcome:       document.getElementById('screen-welcome'),
    practiceIntro: document.getElementById('screen-practice-intro'),
    part1Intro:    document.getElementById('screen-part1-intro'),
    breakScreen:   document.getElementById('screen-break'),
    part2Intro:    document.getElementById('screen-part2-intro'),
    breakScreen2:  document.getElementById('screen-break-2'),
    part3Intro:    document.getElementById('screen-part3-intro'),
    end:           document.getElementById('screen-end')
  },
  participantId:  document.getElementById('participant-id'),
  idError:        document.getElementById('id-error'),
  clap:           document.getElementById('clap'),
  footer:         document.getElementById('researcher-footer')
};

/* ---------- Apply the language table to the interface ---------- */
function applyStrings(){
  document.documentElement.lang = LANG;
  document.documentElement.dir  = (LANG === 'ar') ? 'rtl' : 'ltr';
  document.title = S.docTitle;

  const text = {
    't-welcome-title': S.welcomeTitle,
    't-welcome-1': S.welcome1,
    't-welcome-2': S.welcome2,
    't-welcome-3': S.welcome3,
    't-welcome-4': S.welcome4,
    't-welcome-5': S.welcome5,
    't-pid-label': S.pidLabel,
    'btn-start': S.start,
    't-practice-title': S.practiceTitle,
    't-practice-body': S.instruction,
    'btn-practice': S.begin,
    't-part1-title': S.part1Title,
    't-part1-body': S.instruction,
    'btn-part1': S.begin,
    't-break1-title': S.break1Title,
    't-break1-body': S.breakBody,
    'btn-continue': S.continueBtn,
    't-part2-title': S.part2Title,
    't-part2-body': S.instruction,
    'btn-part2': S.begin,
    't-break2-title': S.break2Title,
    't-break2-body': S.breakBody,
    'btn-continue-2': S.continueBtn,
    't-part3-title': S.part3Title,
    't-part3-body': S.instruction,
    'btn-part3': S.begin,
    't-end-title': S.endTitle,
    't-end-body': S.endBody,
    't-footer-note': S.footerNote,
    'btn-download-csv': S.downloadCsv,
    'btn-download-json': S.downloadJson
  };
  Object.entries(text).forEach(([id, value]) => {
    const node = document.getElementById(id);
    if (node) node.textContent = value;
  });
  el.participantId.placeholder = S.pidPlaceholder;
}

let currentGrid = null;
let currentGridKey = null;
let currentCellSize = 0;
let currentAOIs = [];
let cellByAOI = {};

/**
 * Build (or rebuild) the response grid for a { rows, cols } layout.
 * Boxes are made as large as the available area allows, so a part with
 * fewer boxes automatically gets larger boxes and larger icons. The grid
 * always stays centred on the same point in every part.
 */
function buildGrid(grid){
  const key = gridKey(grid);
  if (currentGridKey === key) return;
  currentGrid = grid;
  currentGridKey = key;
  currentAOIs = aoiIdsFor(grid);
  cellByAOI = {};
  el.grid.innerHTML = '';

  const maxByHeight = (GRID_AREA_PX      - CELL_GAP_PX * (grid.rows - 1)) / grid.rows;
  const maxByWidth  = (GRID_MAX_WIDTH_PX - CELL_GAP_PX * (grid.cols - 1)) / grid.cols;
  const cellSize = Math.floor(Math.min(maxByHeight, maxByWidth));
  const iconSize = Math.round(cellSize * ICON_FILL_RATIO);
  currentCellSize = cellSize;
  const totalW   = cellSize * grid.cols + CELL_GAP_PX * (grid.cols - 1);
  const totalH   = cellSize * grid.rows + CELL_GAP_PX * (grid.rows - 1);

  /* Emit sizes in vmin instead of px. The grid was designed on the 1080px-tall
     surface, so 1 design px = (100/1080)vmin. Because vmin is resolved live by
     the browser's layout engine, the boxes rescale automatically on every
     resize / fullscreen change with no JavaScript and no fixed canvas. */
  const DPX_TO_VMIN = 100 / 1080;
  const vmin = px => (px * DPX_TO_VMIN).toFixed(4) + 'vmin';

  el.grid.style.width  = vmin(totalW);
  el.grid.style.height = vmin(totalH);
  el.grid.style.gridTemplateColumns = `repeat(${grid.cols}, ${vmin(cellSize)})`;
  el.grid.style.gridTemplateRows    = `repeat(${grid.rows}, ${vmin(cellSize)})`;
  el.grid.style.gap = vmin(CELL_GAP_PX);

  currentAOIs.forEach(aoi => {
    const cell = document.createElement('div');
    cell.className = 'cell';
    cell.dataset.aoi = aoi;
    cell.style.width  = vmin(cellSize);
    cell.style.height = vmin(cellSize);

    const holder = document.createElement('div');
    holder.className = 'cell-icon';
    holder.style.width  = vmin(iconSize);
    holder.style.height = vmin(iconSize);

    cell.appendChild(holder);
    el.grid.appendChild(cell);
    cellByAOI[aoi] = { cell, holder };
  });

  console.log(`[GRID] ${key} = ${gridCells(grid)} boxes | cell ${cellSize}px | icon ${iconSize}px`);
}

/** Uniformly scale the 1920x1080 design surface to fit the viewport.
 *  Uses visualViewport when available (more accurate inside embedded
 *  containers such as the Tobii Pro Lab Chromium presenter) and recomputes
 *  on any container size change, not only the window 'resize' event. */
function fitStage(){
  // Always compute a PLAIN NUMERIC scale with Math.min (no CSS min()/clamp(),
  // which the old Chromium in the Pro Lab presenter can't parse). Measure the
  // viewport conservatively so the 1920x1080 stage never overflows the visible
  // area, then re-run on every event/timer below to catch the async fullscreen
  // transition, during which resize events fire unreliably in the presenter.
  const q = new URLSearchParams(window.location.search);
  const forcedScale = parseFloat(q.get('scale'));
  const forcedW = parseFloat(q.get('vw'));
  const forcedH = parseFloat(q.get('vh'));

  let s;
  if (forcedScale > 0){
    s = forcedScale;
  } else {
    const vv = window.visualViewport;
    const widths = [
      window.innerWidth,
      document.documentElement && document.documentElement.clientWidth,
      vv && vv.width,
      window.screen && window.screen.availWidth
    ].filter(function(n){ return typeof n === 'number' && n > 0; });
    const heights = [
      window.innerHeight,
      document.documentElement && document.documentElement.clientHeight,
      vv && vv.height,
      window.screen && window.screen.availHeight
    ].filter(function(n){ return typeof n === 'number' && n > 0; });

    let w = widths.length  ? Math.min.apply(null, widths)  : 1920;
    let h = heights.length ? Math.min.apply(null, heights) : 1080;
    if (forcedW > 0) w = forcedW;
    if (forcedH > 0) h = forcedH;

    s = Math.min(w / 1920, h / 1080);
  }

  if (!(s > 0)) s = 1;
  // Only write when the value actually changes, so the continuous timer below
  // is essentially free and never causes layout thrash.
  if (s !== fitStage._last){
    fitStage._last = s;
    document.documentElement.style.setProperty('--scale', String(s));
  }
  updateDebugReadout(window.innerWidth, window.innerHeight, s);
}
fitStage._last = null;

/** Optional on-screen diagnostics: append ?debug=1 to the URL to show the
 *  measured viewport and computed scale. Purely for troubleshooting the
 *  Tobii Pro Lab presenter; it never shows during a normal session. */
function updateDebugReadout(w, h, s){
  try{
    if (!/[?&]debug=1\b/.test(window.location.search)) return;
    let el = document.getElementById('debug-readout');
    if (!el){
      el = document.createElement('div');
      el.id = 'debug-readout';
      el.style.cssText = 'position:fixed;top:0;left:0;z-index:99999;'
        + 'background:#000;color:#0f0;font:14px/1.4 monospace;'
        + 'padding:6px 10px;white-space:pre;pointer-events:none;';
      document.body.appendChild(el);
    }
    const vv = window.visualViewport;
    // Actual rendered scale = measured stage width / its 1920px design width.
    let actual = 'n/a';
    const stage = document.getElementById('stage');
    if (stage){ actual = (stage.getBoundingClientRect().width / 1920).toFixed(4); }
    el.textContent =
      'window.inner:        ' + window.innerWidth + ' x ' + window.innerHeight + '\n' +
      'documentElement:     ' + document.documentElement.clientWidth + ' x ' + document.documentElement.clientHeight + '\n' +
      'visualViewport:      ' + (vv ? Math.round(vv.width) + ' x ' + Math.round(vv.height) : 'n/a') + '\n' +
      'screen.avail:        ' + window.screen.availWidth + ' x ' + window.screen.availHeight + '\n' +
      'devicePixelRatio:    ' + window.devicePixelRatio + '\n' +
      'rendered scale:      ' + actual;
  }catch(e){ /* diagnostics must never break the task */ }
}

// Recompute on every event that can change the presented size.
window.addEventListener('resize', fitStage);
window.addEventListener('orientationchange', fitStage);
window.addEventListener('load', fitStage);
document.addEventListener('DOMContentLoaded', fitStage);
// Entering/leaving fullscreen changes the viewport asynchronously; refit when
// the state actually changes (covers both standard and webkit prefixes).
document.addEventListener('fullscreenchange', fitStage);
document.addEventListener('webkitfullscreenchange', fitStage);
if (window.visualViewport){
  window.visualViewport.addEventListener('resize', fitStage);
  window.visualViewport.addEventListener('scroll', fitStage);
}
// Pro Lab often resizes the container without firing 'resize'; observe it.
if (window.ResizeObserver){
  const ro = new ResizeObserver(fitStage);
  ro.observe(document.documentElement);
}
// BULLETPROOF FALLBACK: the Tobii Pro Lab presenter does not reliably fire
// resize/fullscreenchange, and the fullscreen transition (triggered after the
// participant enters their ID) resizes the viewport asynchronously. Rather
// than trust any single event, re-fit on a continuous low-frequency timer.
// fitStage() only writes to the DOM when the computed scale actually changes,
// so this is effectively free once the layout has settled.
  [0, 100, 300, 800].forEach(function(t){ setTimeout(fitStage, t); });
  fitStage();

const SCREEN_URL_LABEL = {
  welcome: 'welcome',           practiceIntro: 'practice-intro',
  part1Intro: 'part1-intro',    breakScreen: 'break-1',
  part2Intro: 'part2-intro',    breakScreen2: 'break-2',
  part3Intro: 'part3-intro',    end: 'finished'
};

function showScreen(key){
  Object.values(el.screens).forEach(s => s.classList.add('hidden'));
  if (key) el.screens[key].classList.remove('hidden');
  el.taskLayer.classList.toggle('hidden', key !== null);

  if (key && SCREEN_URL_LABEL[key]){
    setPageUrl(SCREEN_URL_LABEL[key], {
      pid: session.participant_id || '',
      screen: SCREEN_URL_LABEL[key]
    });
  }
}

/* The + and the boxes are controlled separately.
   The cross is shown ONCE per trial, at the very start; the retention
   gap and the gap between trials are completely blank. */
function setFixation(visible){
  el.fixation.classList.toggle('hidden', !visible);
}

function setGridVisible(visible){
  el.grid.classList.toggle('grid-hidden', !visible);
}

function clearGridIcons(){
  currentAOIs.forEach(aoi => { cellByAOI[aoi].holder.innerHTML = ''; });
}

function clearPrompt(){
  el.promptText.textContent = '';
  el.targetIcon.innerHTML = '';
  clearFeedback();
  clearClap();
}

function showFeedback(text, kind){
  el.promptText.textContent = '';
  el.targetIcon.innerHTML = '';
  el.feedbackText.textContent = text;
  el.feedbackText.className = kind;
}

function clearFeedback(){
  el.feedbackText.textContent = '';
  el.feedbackText.className = '';
}

/**
 * Peek under a wrongly chosen box: show whatever had been in that
 * location during the memory display, or a short word if it was empty.
 */
function showHint(aoi, objectName){
  const { cell, holder } = cellByAOI[aoi];
  cell.classList.add('hint');
  if (objectName){
    holder.innerHTML = ICON_HTML[objectName];
  } else {
    holder.innerHTML = `<span class="empty-label">${S.emptyBox}</span>`;
    const label = holder.querySelector('.empty-label');
    if (label) label.style.fontSize = Math.round(currentCellSize * 0.13) + 'px';
  }
}

function clearHint(aoi){
  cellByAOI[aoi].cell.classList.remove('hint');
  cellByAOI[aoi].holder.innerHTML = '';
}

/** Applause after a practice trial (practice only). */
function showClap(){
  el.clap.innerHTML = CLAP_HTML;
  el.clap.classList.remove('hidden');
  void el.clap.offsetWidth;              // restart the pop animation
  el.clap.classList.add('show');
}

function clearClap(){
  el.clap.classList.add('hidden');
  el.clap.classList.remove('show');
  el.clap.innerHTML = '';
}


/* ---------- Per-trial URLs ---------- */

/**
 * Point the address bar at a new URL without reloading the page.
 * Returns the resulting full URL so it can be stored with the trial.
 */
function setPageUrl(label, params){
  if (!UNIQUE_URL_PER_TRIAL) return location.href;

  const query = new URLSearchParams(params).toString();
  const target = `${location.pathname}?${query}#${label}`;

  try {
    if (URL_HISTORY_MODE === 'replace') history.replaceState({ label }, '', target);
    else                                history.pushState({ label }, '', target);
  } catch (e) {
    // file:// blocks history manipulation - the hash still changes the URL
    location.hash = label;
  }
  return location.href;
}


/* =========================================================================
   7. SESSION STATE, EVENT LOG, AOI CAPTURE
   ========================================================================= */

const session = {
  participant_id: '',
  session_start_iso: '',
  session_start_perf: 0,
  screen: {},
  config: {},
  practiceTrials: [],
  part1Trials: [],
  part2Trials: [],
  part3Trials: [],
  data: [],
  events: []
};

/** Log an event marker with a high-resolution timestamp. */
function logEvent(label, detail){
  const evt = {
    label,
    performance_now_ms: performance.now(),
    iso_time: isoNow(),
    unix_ms: Date.now()
  };
  if (detail) evt.detail = detail;
  session.events.push(evt);
  console.log(`[EVENT] ${evt.performance_now_ms.toFixed(2)} ms  ${label}`, detail || '');
  return evt.performance_now_ms;
}

/**
 * Capture the on-screen geometry of every AOI in the current grid, plus
 * the icon drawn inside it. Coordinates are given in viewport space and
 * in physical screen space (what most eye trackers report).
 */
function captureAOIGeometry(placement){
  const offX = (window.screenX || 0) + (window.outerWidth - window.innerWidth) / 2;
  const offY = (window.screenY || 0) + (window.outerHeight - window.innerHeight);
  const labels = aoiLabelMapFor(currentGrid);

  return currentAOIs.map(aoi => {
    const r = cellByAOI[aoi].cell.getBoundingClientRect();
    const iconEl = cellByAOI[aoi].holder.firstElementChild;
    const ir = iconEl ? iconEl.getBoundingClientRect() : null;
    return {
      aoi,
      aoi_label: labels[aoi],
      object: placement && placement[aoi] ? placement[aoi] : null,
      x: round2(r.left), y: round2(r.top),
      width: round2(r.width), height: round2(r.height),
      center_x: round2(r.left + r.width / 2),
      center_y: round2(r.top + r.height / 2),
      screen_x: round2(r.left + offX),
      screen_y: round2(r.top + offY),
      screen_center_x: round2(r.left + r.width / 2 + offX),
      screen_center_y: round2(r.top + r.height / 2 + offY),
      icon_x: ir ? round2(ir.left) : null,
      icon_y: ir ? round2(ir.top) : null,
      icon_width:  ir ? round2(ir.width)  : null,
      icon_height: ir ? round2(ir.height) : null,
      icon_screen_center_x: ir ? round2(ir.left + ir.width / 2 + offX) : null,
      icon_screen_center_y: ir ? round2(ir.top + ir.height / 2 + offY) : null
    };
  });
}


/* =========================================================================
   8. TRIAL ENGINE
      One + (500 ms) -> boxes with icons -> blank -> question -> blank
      The cross appears exactly once per trial, at the start.
      The response stage allows up to MAX_ATTEMPTS answers per trial.
   ========================================================================= */

/** Event-marker prefix, e.g. PART1_TRIAL03 / PART2_TRIAL07 / PRACTICE_TRIAL01 */
function eventTag(trial){
  const block = trial.part === 'Part 1' ? 'PART1'
              : trial.part === 'Part 2' ? 'PART2'
              : trial.part === 'Part 3' ? 'PART3'
              : 'PRACTICE';
  return `${block}_TRIAL${pad2(trial.trial_number)}`;
}

/** Wait for a box click. With RESPONSE_TIMEOUT_MS = 0 this waits indefinitely. */
function collectResponse(){
  return new Promise(resolve => {
    let done = false;
    const start = performance.now();
    let timer = null;

    const onClick = (e) => {
      const cell = e.target.closest('.cell');
      if (!cell || done) return;
      done = true;
      cleanup();
      resolve({
        aoi: cell.dataset.aoi,
        rt: performance.now() - start,
        timeout: false,
        client_x: e.clientX,
        client_y: e.clientY
      });
    };

    if (RESPONSE_TIMEOUT_MS > 0){
      timer = setTimeout(() => {
        if (done) return;
        done = true;
        cleanup();
        resolve({ aoi: null, rt: null, timeout: true, client_x: null, client_y: null });
      }, RESPONSE_TIMEOUT_MS);
    }

    function cleanup(){
      if (timer) clearTimeout(timer);
      el.grid.removeEventListener('click', onClick);
      currentAOIs.forEach(a => cellByAOI[a].cell.classList.remove('clickable'));
    }

    currentAOIs.forEach(a => cellByAOI[a].cell.classList.add('clickable'));
    el.grid.addEventListener('click', onClick);
  });
}

/** Shake a box to signal "not that one, try again". */
async function shakeCell(aoi){
  const c = cellByAOI[aoi].cell;
  c.classList.remove('shake');
  void c.offsetWidth;                    // force the animation to restart
  c.classList.add('shake');
  await sleep(SHAKE_DURATION_MS);
  c.classList.remove('shake');
}

/** Response stage: first answer, optional shake, second chance, feedback. */
async function runResponsePhase(trial, tag, isPractice){
  el.promptText.textContent = S.prompt;
  el.targetIcon.innerHTML = ICON_HTML[trial.target_object];

  trial.response_screen_start = logEvent(`${tag}_TARGET_START`, {
    target_object: trial.target_object,
    target_correct_location: trial.target_correct_location
  });

  const attempts = [];
  let solved = false;
  let timedOut = false;
  let hintLocation = null;
  let hintContent  = null;

  for (let a = 1; a <= MAX_ATTEMPTS && !solved && !timedOut; a++){
    if (a > 1) logEvent(`${tag}_SECOND_CHANCE_START`);

    const resp = await collectResponse();
    const correct = !resp.timeout && resp.aoi === trial.target_correct_location;

    attempts.push({
      attempt: a,
      selected_location: resp.aoi,
      correct: correct ? 1 : 0,
      reaction_time_ms: resp.rt === null ? null : Math.round(resp.rt * 100) / 100,
      timeout: resp.timeout,
      timestamp: performance.now(),
      click_x: resp.client_x,
      click_y: resp.client_y
    });

    if (resp.timeout){
      timedOut = true;
      logEvent(`${tag}_TIMEOUT_ATTEMPT${a}`);
      break;
    }

    logEvent(`${tag}_RESPONSE_ATTEMPT${a}`, {
      selected_location: resp.aoi,
      correct_location: trial.target_correct_location,
      correct: correct ? 1 : 0,
      reaction_time_ms: attempts[a - 1].reaction_time_ms,
      click_x: resp.client_x,
      click_y: resp.client_y
    });

    if (correct){
      solved = true;
      // The picture reappears in the box the child chose, so a correct
      // answer is confirmed in place as well as in words.
      cellByAOI[resp.aoi].cell.classList.add('correct');
      cellByAOI[resp.aoi].holder.innerHTML = ICON_HTML[trial.target_object];
      showFeedback(S.correct, 'correct');
      if (isPractice){ showClap(); logEvent(`${tag}_PRACTICE_CLAP`); }
      logEvent(`${tag}_FEEDBACK_CORRECT`, { attempt: a, icon_shown_at: resp.aoi });
      await sleep(isPractice ? PRACTICE_FEEDBACK_MS : FEEDBACK_DURATION_MS);
      cellByAOI[resp.aoi].cell.classList.remove('correct');
      cellByAOI[resp.aoi].holder.innerHTML = '';
      clearClap();
      clearFeedback();
    } else {
      logEvent(`${tag}_SHAKE_ATTEMPT${a}`, { shaken_location: resp.aoi });
      await shakeCell(resp.aoi);

      // One hint only, after the FIRST wrong answer: show what had
      // actually been in that box during the memory display.
      if (SHOW_HINT && a < MAX_ATTEMPTS){
        const under = trial.placement[resp.aoi] || null;
        hintLocation = resp.aoi;
        hintContent  = under || 'empty';
        showHint(resp.aoi, under);
        logEvent(`${tag}_HINT_SHOWN`, { location: resp.aoi, content: hintContent });
        await sleep(HINT_DURATION_MS);
        clearHint(resp.aoi);
      }

      if (a === MAX_ATTEMPTS){
        // Out of chances: move on without revealing the correct box.
        showFeedback(S.tryNext, 'retry');
        if (isPractice){ showClap(); logEvent(`${tag}_PRACTICE_CLAP`); }
        logEvent(`${tag}_FEEDBACK_NEXT`);
        await sleep(isPractice ? PRACTICE_FEEDBACK_MS : FEEDBACK_DURATION_MS);
        clearClap();
        clearFeedback();
      }
    }
  }

  return { attempts, solved, timedOut, hintLocation, hintContent };
}

/**
 * Run a single trial (practice or experimental).
 * @param {object} trial
 * @param {object} opts { isPractice, indexInBlock, blockLength, globalNumber }
 */
async function runTrial(trial, opts){
  const tag = eventTag(trial);

  buildGrid(trial.grid);

  trial.trial_start_timestamp = isoNow();
  trial.trial_start_perf = performance.now();

  // A fresh URL for this trial, e.g.  ...?pid=P001&part=1&trial=03#part1-trial03
  const urlLabel = `${trial.part.toLowerCase().replace(' ', '')}-trial${pad2(trial.trial_number)}`;
  trial.url = setPageUrl(urlLabel, {
    pid:   session.participant_id,
    part:  trial.part,
    trial: pad2(trial.trial_number),
    boxes: trial.n_grid_locations,
    items: trial.number_of_objects
  });
  logEvent(`${tag}_URL`, { url: trial.url, label: urlLabel });

  // ---------- Slide 1: fixation ----------
  clearPrompt();
  clearGridIcons();
  el.progress.textContent = opts.isPractice
    ? S.practiceProgress(opts.indexInBlock, opts.blockLength)
    : S.progress(opts.indexInBlock, opts.blockLength);

  setGridVisible(false);
  setFixation(true);
  logEvent(`${tag}_FIXATION_START`, { grid: trial.grid_size });
  await sleep(FIXATION_DURATION_MS);
  setFixation(false);

  // ---------- Slide 2: memory display ----------
  // Icons appear immediately, stay stationary, and do not animate.
  setGridVisible(true);
  currentAOIs.forEach(aoi => {
    const obj = trial.placement[aoi];
    cellByAOI[aoi].holder.innerHTML = obj ? ICON_HTML[obj] : '';
  });

  const aoiGeometry = captureAOIGeometry(trial.placement);
  trial.aoi_geometry = aoiGeometry;

  trial.memory_display_start = logEvent(`${tag}_MEMORY_START`, {
    grid: trial.grid_size,
    number_of_objects: trial.number_of_objects,
    aoi_layout: aoiGeometry.filter(a => a.object !== null)
                           .map(a => `${a.aoi}=${a.object}`),
    aoi_geometry: aoiGeometry
  });

  await sleep(MEMORY_DURATION_MS);

  setGridVisible(false);
  clearGridIcons();
  trial.memory_display_end = logEvent(`${tag}_MEMORY_END`);

  // ---------- Slide 3: retention (blank screen, no cross, no boxes) ----------
  trial.retention_start = logEvent(`${tag}_RETENTION_START`);
  await sleep(RETENTION_DURATION_MS);

  // ---------- Slide 4: find the location (up to two attempts) ----------
  setGridVisible(true);
  const result = await runResponsePhase(trial, tag, opts.isPractice);

  const first  = result.attempts[0] || null;
  const second = result.attempts[1] || null;

  trial.attempts = result.attempts;
  trial.n_attempts = result.attempts.length;
  trial.timeout = result.timedOut;
  trial.participant_selected_location = first ? first.selected_location : null;
  trial.accuracy = first ? first.correct : 0;                 // primary measure
  trial.reaction_time_ms = first ? first.reaction_time_ms : null;
  trial.attempt2_selected_location = second ? second.selected_location : null;
  trial.attempt2_accuracy = second ? second.correct : null;
  trial.attempt2_reaction_time_ms = second ? second.reaction_time_ms : null;
  trial.accuracy_within_two_attempts = result.solved ? 1 : 0;
  trial.hint_location = result.hintLocation;
  trial.hint_content  = result.hintContent;
  trial.response_timestamp = first ? first.timestamp : null;
  trial.final_response_timestamp = result.attempts.length
    ? result.attempts[result.attempts.length - 1].timestamp : null;

  clearPrompt();

  // ---------- Slide 5: blank gap before the next trial's + ----------
  const iti = randInt(ITI_MIN_MS, ITI_MAX_MS);
  trial.iti_ms = iti;
  setGridVisible(false);
  logEvent(`${tag}_ITI_START`, { iti_ms: iti });
  await sleep(iti);

  trial.trial_end_timestamp = isoNow();
  trial.global_trial_number = opts.globalNumber;

  if (!opts.isPractice) session.data.push(buildDataRow(trial));
}

/** Flatten a finished trial into one export row. */
function buildDataRow(trial){
  const locationString = Object.keys(trial.placement)
    .sort((a, b) => Number(a.split('_')[1]) - Number(b.split('_')[1]))
    .map(a => `${a}:${trial.placement[a]}`)
    .join(';');

  return {
    participant_id:                session.participant_id,
    part:                          trial.part,
    condition_code:                trial.condition_code,
    trial_number:                  trial.trial_number,
    global_trial_number:           trial.global_trial_number,
    grid_size:                     trial.grid_size,
    n_grid_locations:              trial.n_grid_locations,
    number_of_objects:             trial.number_of_objects,
    objects_presented:             trial.objects_presented.join(';'),
    object_locations:              locationString,
    target_object:                 trial.target_object,
    target_correct_location:       trial.target_correct_location,
    participant_selected_location: trial.participant_selected_location || '',
    accuracy:                      trial.accuracy,
    reaction_time_ms:              trial.reaction_time_ms === null ? '' : trial.reaction_time_ms,
    n_attempts:                    trial.n_attempts,
    attempt2_selected_location:    trial.attempt2_selected_location || '',
    attempt2_accuracy:             trial.attempt2_accuracy === null ? '' : trial.attempt2_accuracy,
    attempt2_reaction_time_ms:     trial.attempt2_reaction_time_ms === null ? '' : trial.attempt2_reaction_time_ms,
    accuracy_within_two_attempts:  trial.accuracy_within_two_attempts,
    hint_location:                 trial.hint_location || '',
    hint_content:                  trial.hint_content  || '',
    memory_display_start:          round2(trial.memory_display_start),
    memory_display_end:            round2(trial.memory_display_end),
    retention_start:               round2(trial.retention_start),
    response_screen_start:         round2(trial.response_screen_start),
    response_timestamp:            round2(trial.response_timestamp),
    final_response_timestamp:      round2(trial.final_response_timestamp),
    timeout:                       trial.timeout ? 1 : 0,
    trial_url:                     trial.url || '',
    trial_start_timestamp:         trial.trial_start_timestamp,
    trial_end_timestamp:           trial.trial_end_timestamp,
    iti_ms:                        trial.iti_ms
  };
}


/* =========================================================================
   9. BLOCK / SESSION FLOW
   ========================================================================= */

let globalTrialCounter = 0;

async function runBlock(trials, isPractice){
  for (let i = 0; i < trials.length; i++){
    if (!isPractice) globalTrialCounter++;
    await runTrial(trials[i], {
      isPractice,
      indexInBlock: i + 1,
      blockLength: trials.length,
      globalNumber: isPractice ? null : globalTrialCounter
    });
  }
  clearPrompt();
  clearGridIcons();
  setFixation(false);
  setGridVisible(false);
  el.progress.textContent = '';
}

/** Build the full randomised session configuration before anything starts. */
function buildSession(){
  session.practiceTrials = buildBlock('Practice', 'practice',    PRACTICE_TRIALS, PART1_OBJECT_COUNT, PART1_GRID, PART1_POOL);
  session.part1Trials    = buildBlock('Part 1',   'condition_A', PART1_TRIALS,    PART1_OBJECT_COUNT, PART1_GRID, PART1_POOL);
  session.part2Trials    = buildBlock('Part 2',   'condition_B', PART2_TRIALS,    PART2_OBJECT_COUNT, PART2_GRID, PART2_POOL);
  session.part3Trials    = buildBlock('Part 3',   'condition_C', PART3_TRIALS,    PART3_OBJECT_COUNT, PART3_GRID, PART3_POOL);

  session.config = {
    PART1_TRIALS, PART2_TRIALS, PART3_TRIALS,
    PART1_GRID, PART2_GRID, PART3_GRID,
    PART1_OBJECT_COUNT, PART2_OBJECT_COUNT, PART3_OBJECT_COUNT,
    PART1_POOL, PART2_POOL, PART3_POOL,
    FIXATION_DURATION_MS, MEMORY_DURATION_MS, RETENTION_DURATION_MS,
    RESPONSE_TIMEOUT_MS, PRACTICE_TRIALS, MAX_ATTEMPTS,
    FEEDBACK_DURATION_MS, PRACTICE_FEEDBACK_MS, SHAKE_DURATION_MS,
    HINT_DURATION_MS, SHOW_HINT,
    UNIQUE_URL_PER_TRIAL, URL_HISTORY_MODE,
    LANG,
    ITI_MIN_MS, ITI_MAX_MS,
    GRID_AREA_PX, GRID_MAX_WIDTH_PX, CELL_GAP_PX, ICON_FILL_RATIO,
    part1_aoi_labels: aoiLabelMapFor(PART1_GRID),
    part2_aoi_labels: aoiLabelMapFor(PART2_GRID),
    part3_aoi_labels: aoiLabelMapFor(PART3_GRID),
    chance_level: {
      'Part 1': round2(1 / gridCells(PART1_GRID)),
      'Part 2': round2(1 / gridCells(PART2_GRID)),
      'Part 3': round2(1 / gridCells(PART3_GRID))
    },
    condition_map: { 'Part 1': 'condition_A', 'Part 2': 'condition_B', 'Part 3': 'condition_C' }
  };

  console.log('[CONFIG] Randomised session configuration', {
    practice: session.practiceTrials,
    part1: session.part1Trials,
    part2: session.part2Trials,
    part3: session.part3Trials
  });
}

/* ---------- Button wiring ---------- */

/* button wiring handled by STEP CONTROLLER */



/* =========================================================================
   10. SUMMARY STATISTICS  (computed internally; never shown to participants)
   ========================================================================= */

function blockStats(rows){
  const n = rows.length;
  const omissions = rows.filter(r => r.timeout === 1).length;
  const correct = rows.filter(r => r.accuracy === 1);
  const solved  = rows.filter(r => r.accuracy_within_two_attempts === 1);
  const meanRT = correct.length
    ? correct.reduce((s, r) => s + Number(r.reaction_time_ms), 0) / correct.length
    : null;
  const secondChances = rows.filter(r => r.n_attempts > 1).length;
  return {
    n_trials: n,
    n_correct_first_attempt: correct.length,
    accuracy: n ? round2(correct.length / n) : null,             // first attempt
    accuracy_within_two_attempts: n ? round2(solved.length / n) : null,
    mean_rt_correct_ms: meanRT === null ? null : round2(meanRT), // first attempt, correct
    second_chances_used: secondChances,
    omissions
  };
}

let cachedSummary = null;

function diff(a, b){                      // b minus a
  return (a === null || b === null) ? null : round2(b - a);
}

function computeSummary(){
  const p1 = blockStats(session.data.filter(r => r.part === 'Part 1'));
  const p2 = blockStats(session.data.filter(r => r.part === 'Part 2'));
  const p3 = blockStats(session.data.filter(r => r.part === 'Part 3'));

  cachedSummary = {
    part1: p1,
    part2: p2,
    part3: p3,
    accuracy_difference_p2_minus_p1: diff(p1.accuracy, p2.accuracy),
    accuracy_difference_p3_minus_p2: diff(p2.accuracy, p3.accuracy),
    accuracy_difference_p3_minus_p1: diff(p1.accuracy, p3.accuracy),
    rt_difference_p2_minus_p1_ms: diff(p1.mean_rt_correct_ms, p2.mean_rt_correct_ms),
    rt_difference_p3_minus_p2_ms: diff(p2.mean_rt_correct_ms, p3.mean_rt_correct_ms),
    rt_difference_p3_minus_p1_ms: diff(p1.mean_rt_correct_ms, p3.mean_rt_correct_ms),
    note: 'accuracy = first-attempt accuracy. Chance level differs between parts because the number of boxes differs (1/4, 1/6, 1/9).'
  };
  return cachedSummary;
}


/* =========================================================================
   11. DATA EXPORT
   ========================================================================= */

const CSV_COLUMNS = [
  'participant_id','part','condition_code','trial_number','global_trial_number',
  'grid_size','n_grid_locations','number_of_objects','objects_presented',
  'object_locations','target_object','target_correct_location',
  'participant_selected_location','accuracy','reaction_time_ms',
  'n_attempts','attempt2_selected_location','attempt2_accuracy',
  'attempt2_reaction_time_ms','accuracy_within_two_attempts',
  'hint_location','hint_content',
  'memory_display_start','memory_display_end','retention_start',
  'response_screen_start','response_timestamp','final_response_timestamp',
  'timeout','trial_url','trial_start_timestamp','trial_end_timestamp','iti_ms'
];

/* Session-level summary values are appended as constant columns so the file
   stays a clean rectangular CSV for R / Python / SPSS. */
const SUMMARY_COLUMNS = [
  'part1_accuracy','part1_accuracy_within_two_attempts','part1_mean_rt_correct_ms','part1_omissions',
  'part2_accuracy','part2_accuracy_within_two_attempts','part2_mean_rt_correct_ms','part2_omissions',
  'part3_accuracy','part3_accuracy_within_two_attempts','part3_mean_rt_correct_ms','part3_omissions',
  'accuracy_difference_p2_minus_p1','accuracy_difference_p3_minus_p2','accuracy_difference_p3_minus_p1',
  'rt_difference_p2_minus_p1_ms','rt_difference_p3_minus_p2_ms','rt_difference_p3_minus_p1_ms'
];

function csvEscape(v){
  const s = (v === null || v === undefined) ? '' : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function buildCSV(){
  const s = cachedSummary || computeSummary();
  const summaryValues = {
    part1_accuracy: s.part1.accuracy,
    part1_accuracy_within_two_attempts: s.part1.accuracy_within_two_attempts,
    part1_mean_rt_correct_ms: s.part1.mean_rt_correct_ms,
    part1_omissions: s.part1.omissions,
    part2_accuracy: s.part2.accuracy,
    part2_accuracy_within_two_attempts: s.part2.accuracy_within_two_attempts,
    part2_mean_rt_correct_ms: s.part2.mean_rt_correct_ms,
    part2_omissions: s.part2.omissions,
    part3_accuracy: s.part3.accuracy,
    part3_accuracy_within_two_attempts: s.part3.accuracy_within_two_attempts,
    part3_mean_rt_correct_ms: s.part3.mean_rt_correct_ms,
    part3_omissions: s.part3.omissions,
    accuracy_difference_p2_minus_p1: s.accuracy_difference_p2_minus_p1,
    accuracy_difference_p3_minus_p2: s.accuracy_difference_p3_minus_p2,
    accuracy_difference_p3_minus_p1: s.accuracy_difference_p3_minus_p1,
    rt_difference_p2_minus_p1_ms: s.rt_difference_p2_minus_p1_ms,
    rt_difference_p3_minus_p2_ms: s.rt_difference_p3_minus_p2_ms,
    rt_difference_p3_minus_p1_ms: s.rt_difference_p3_minus_p1_ms
  };

  const header = [...CSV_COLUMNS, ...SUMMARY_COLUMNS].join(',');
  const lines = session.data.map(row => {
    const trialPart = CSV_COLUMNS.map(c => csvEscape(row[c]));
    const summPart  = SUMMARY_COLUMNS.map(c => csvEscape(summaryValues[c]));
    return [...trialPart, ...summPart].join(',');
  });
  return [header, ...lines].join('\n');
}

function stripRuntime(t){
  return {
    part: t.part,
    condition_code: t.condition_code,
    trial_number: t.trial_number,
    grid_size: t.grid_size,
    n_grid_locations: t.n_grid_locations,
    number_of_objects: t.number_of_objects,
    objects_presented: t.objects_presented,
    placement: t.placement,
    target_object: t.target_object,
    target_correct_location: t.target_correct_location
  };
}

function buildJSON(){
  const s = cachedSummary || computeSummary();
  return JSON.stringify({
    participant_id: session.participant_id,
    session_start_iso: session.session_start_iso,
    export_iso: isoNow(),
    screen: session.screen,
    user_agent: navigator.userAgent,
    config: session.config,
    randomised_configuration: {
      practice: session.practiceTrials.map(stripRuntime),
      part1: session.part1Trials.map(stripRuntime),
      part2: session.part2Trials.map(stripRuntime),
      part3: session.part3Trials.map(stripRuntime)
    },
    aoi_geometry_by_trial: [...session.part1Trials, ...session.part2Trials, ...session.part3Trials].map(t => ({
      part: t.part,
      trial_number: t.trial_number,
      global_trial_number: t.global_trial_number,
      grid_size: t.grid_size,
      aoi_geometry: t.aoi_geometry || null
    })),
    attempts_by_trial: [...session.part1Trials, ...session.part2Trials, ...session.part3Trials].map(t => ({
      part: t.part,
      trial_number: t.trial_number,
      target_object: t.target_object,
      target_correct_location: t.target_correct_location,
      attempts: t.attempts
    })),
    trials: session.data,
    summary: s,
    events: session.events
  }, null, 2);
}

function downloadFile(filename, text, mime){
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function downloadCSV(){
  const name = `location_memory_${session.participant_id}_${dateStamp()}.csv`;
  downloadFile(name, buildCSV(), 'text/csv;charset=utf-8;');
  logEvent('DATA_EXPORT_CSV', { filename: name });
}

function downloadJSON(){
  const name = `location_memory_events_${session.participant_id}_${dateStamp()}.json`;
  downloadFile(name, buildJSON(), 'application/json;charset=utf-8;');
  logEvent('DATA_EXPORT_JSON', { filename: name });
}

/* boot handled by STEP CONTROLLER */




/* ==========================================================================
   STEP CONTROLLER — one physical HTML file per trial with real navigation.
   Requires window.LMT_STEP (set by each generated HTML file).
   Reuses the engine above verbatim (randomisation, runTrial, logging, export).
   ========================================================================== */
(function(){
  var STEP = window.LMT_STEP || { kind: 'hub' };
  var HUB  = 'location_memory_task_EN1.html';  /* renamed to match Tobii URL */
  var SKEY = 'lmt_session_v1';
  var PKEY = 'lmt_pointer_v1';
  var FILE = { practiceTrials:'t_practice', part1Trials:'t_part1', part2Trials:'t_part2', part3Trials:'t_part3' };

  function p2(n){ n = String(n); return n.length < 2 ? '0'+n : n; }

  function saveSession(){
    try {
      sessionStorage.setItem(SKEY, JSON.stringify({
        participant_id: session.participant_id,
        session_start_iso: session.session_start_iso,
        session_start_perf: session.session_start_perf,
        screen: session.screen,
        config: session.config,
        practiceTrials: session.practiceTrials,
        part1Trials: session.part1Trials,
        part2Trials: session.part2Trials,
        part3Trials: session.part3Trials,
        data: session.data,
        events: session.events,
        globalTrialCounter: globalTrialCounter
      }));
    } catch(e){ console.log('[LMT] saveSession failed', e); }
  }
  function restoreSession(){
    var raw = sessionStorage.getItem(SKEY);
    if (!raw) return false;
    try {
      var o = JSON.parse(raw);
      for (var k in o){ if (k !== 'globalTrialCounter' && Object.prototype.hasOwnProperty.call(o,k)) session[k] = o[k]; }
      if (typeof o.globalTrialCounter === 'number') globalTrialCounter = o.globalTrialCounter;
      return true;
    } catch(e){ return false; }
  }
  function getPointer(){ var v = parseInt(sessionStorage.getItem(PKEY), 10); return isNaN(v) ? 0 : v; }
  function setPointer(p){ sessionStorage.setItem(PKEY, String(p)); }

  function program(){
    var prog = [{ t:'screen', s:'practiceIntro' }];
    (session.practiceTrials||[]).forEach(function(_, i){ prog.push({ t:'trial', block:'practiceTrials', i:i, practice:true }); });
    prog.push({ t:'screen', s:'part1Intro' });
    (session.part1Trials||[]).forEach(function(_, i){ prog.push({ t:'trial', block:'part1Trials', i:i, practice:false }); });
    prog.push({ t:'screen', s:'breakScreen' });
    prog.push({ t:'screen', s:'part2Intro' });
    (session.part2Trials||[]).forEach(function(_, i){ prog.push({ t:'trial', block:'part2Trials', i:i, practice:false }); });
    prog.push({ t:'screen', s:'breakScreen2' });
    prog.push({ t:'screen', s:'part3Intro' });
    (session.part3Trials||[]).forEach(function(_, i){ prog.push({ t:'trial', block:'part3Trials', i:i, practice:false }); });
    prog.push({ t:'screen', s:'end' });
    return prog;
  }

  function urlForTrial(block, i){
    var t = session[block][i];
    var q = new URLSearchParams({
      pid:   session.participant_id || '',
      part:  t.part,
      trial: p2(t.trial_number),
      boxes: t.n_grid_locations,
      items: t.number_of_objects
    }).toString();
    return FILE[block] + '_' + p2(i+1) + '.html?' + q;
  }
  function urlForScreen(s){
    return HUB + '?screen=' + encodeURIComponent(s) + '&pid=' + encodeURIComponent(session.participant_id || '');
  }
  function goToPointer(p){
    setPointer(p);
    var item = program()[p];
    if (!item){ location.href = urlForScreen('end'); return; }
    if (item.t === 'trial'){ location.href = urlForTrial(item.block, item.i); }
    else { location.href = urlForScreen(item.s); }
  }

  var SCREEN_BUTTON = { practiceIntro:'btn-practice', part1Intro:'btn-part1', breakScreen:'btn-continue', part2Intro:'btn-part2', breakScreen2:'btn-continue-2', part3Intro:'btn-part3' };
  var SCREEN_LOG    = { practiceIntro:'PRACTICE_BLOCK_START', part1Intro:'PART1_BLOCK_START', breakScreen:'BREAK_END', part2Intro:'PART2_BLOCK_START', breakScreen2:'BREAK2_END', part3Intro:'PART3_BLOCK_START' };
  var currentScreen = null;

  function wireAdvance(btnId){
    var b = document.getElementById(btnId);
    if (!b) return;
    b.addEventListener('click', function(){
      if (currentScreen && SCREEN_LOG[currentScreen]) logEvent(SCREEN_LOG[currentScreen]);
      saveSession();
      goToPointer(getPointer() + 1);
    });
  }

  function renderScreen(s){
    currentScreen = s;
    if (s === 'end'){
      computeSummary();
      logEvent('SESSION_END', { summary: cachedSummary });
      saveSession();
      showScreen('end');
      if (el.footer) el.footer.classList.remove('hidden');
      var c = document.getElementById('btn-download-csv'); if (c) c.addEventListener('click', downloadCSV);
      var j = document.getElementById('btn-download-json'); if (j) j.addEventListener('click', downloadJSON);
      return;
    }
    showScreen(s);
    wireAdvance(SCREEN_BUTTON[s]);
  }

  async function doStart(){
    var id = el.participantId.value.trim();
    if (!id){ el.idError.textContent = S.pidError; el.participantId.focus(); return; }
    el.idError.textContent = '';
    session.participant_id = id;
    session.session_start_iso = isoNow();
    session.session_start_perf = performance.now();
    session.screen = {
      window_inner_width: window.innerWidth,
      window_inner_height: window.innerHeight,
      screen_width: window.screen.width,
      screen_height: window.screen.height,
      device_pixel_ratio: window.devicePixelRatio,
      stage_scale: getComputedStyle(document.documentElement).getPropertyValue('--scale').trim()
    };
    if (REQUEST_FULLSCREEN && document.documentElement.requestFullscreen){
      try { await document.documentElement.requestFullscreen(); } catch(e){}
    }
    if (typeof fitStage === 'function'){ fitStage(); [50,150,300,600,1000].forEach(function(t){ setTimeout(fitStage, t); }); }
    buildSession();
    logEvent('SESSION_START', { participant_id:id, screen:session.screen });
    saveSession();
    goToPointer(0);                       // program[0] = practiceIntro
  }

  function wireStart(){
    var b = document.getElementById('btn-start');
    if (b) b.addEventListener('click', doStart);
    if (el.participantId) el.participantId.addEventListener('keydown', function(e){
      if (e.key === 'Enter'){ e.preventDefault(); doStart(); }
    });
  }

  function bootHub(){
    applyStrings();
    buildGrid(PART1_GRID);
    var ok = restoreSession();
    if (!ok){
      sessionStorage.removeItem(PKEY);
      showScreen('welcome');
      wireStart();
      return;
    }
    var p = getPointer();
    var item = program()[p];
    if (!item){ renderScreen('end'); return; }
    if (item.t === 'trial'){ location.href = urlForTrial(item.block, item.i); return; }
    renderScreen(item.s);
  }

  async function bootTrial(){
    applyStrings();
    if (!restoreSession()){ location.href = HUB; return; }
    var block = STEP.block, i = STEP.i;
    var arr = session[block];
    if (!arr || !arr[i]){ location.href = HUB; return; }
    var trial = arr[i];
    showScreen(null);                     // hide all screens, reveal task layer
    var globalNumber = null;
    if (!STEP.practice){
      var base = 0;
      if (block === 'part2Trials') base = (session.part1Trials||[]).length;
      else if (block === 'part3Trials') base = (session.part1Trials||[]).length + (session.part2Trials||[]).length;
      globalNumber = base + i + 1;
      globalTrialCounter = globalNumber;
    }
    await runTrial(trial, { isPractice:STEP.practice, indexInBlock:i+1, blockLength:arr.length, globalNumber:globalNumber });
    saveSession();
    goToPointer(getPointer() + 1);
  }

  function run(){ if (STEP.kind === 'trial') bootTrial(); else bootHub(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
})();
